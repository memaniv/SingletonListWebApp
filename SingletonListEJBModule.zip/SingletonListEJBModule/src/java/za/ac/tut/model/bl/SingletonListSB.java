package za.ac.tut.model.bl;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Singleton;

/**
 *
 * @author MemaniV
 */
@Singleton
public class SingletonListSB implements SingletonListSBLocal {

    private List<Integer> numbers = new ArrayList<>();
    
    @Override
    public void add(Integer num) {
        numbers.add(num);
    }
    @Override
    public Integer getSize() {
        return numbers.size();
    }
    @Override
    public List<Integer> getList() {
        return numbers;
    }  
}


